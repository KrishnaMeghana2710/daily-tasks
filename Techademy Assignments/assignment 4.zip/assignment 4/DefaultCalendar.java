import java.util.Calendar;

class DefaultCalendar{
    public static void main(String[] args) {

        //getting current instance
        Calendar calendar = Calendar.getInstance();

        //displaying current time
        System.out.println(calendar.getTime());
    }
}